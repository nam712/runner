create definer = root@localhost view v_room_summary as
select `r`.`id`                AS `id`,
       `r`.`code`              AS `code`,
       `r`.`name`              AS `name`,
       `r`.`amount`            AS `amount`,
       ifnull(`t`.`in_use`, 0) AS `in_use`
from (`db_ktx`.`room` `r` left join (select `c`.`room_code` AS `room_code`, count(`c`.`id`) AS `in_use`
                                     from `db_ktx`.`contract` `c`
                                     where ((1 = 1) and (`c`.`status` = 'ACTIVE'))
                                     group by `c`.`room_code`) `t` on ((`t`.`room_code` = `r`.`code`)));

-- comment on column v_room_summary.code not supported: Mã phòng

-- comment on column v_room_summary.name not supported: Tên phòng

-- comment on column v_room_summary.amount not supported: Số người

